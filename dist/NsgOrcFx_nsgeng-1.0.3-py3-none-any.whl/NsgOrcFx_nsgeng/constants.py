"""
Constants
"""

import math

gravity = 9.81 # (m/s2)
pi = math.pi

dofStrs = ['Ux', 'Uy', 'Uz', 'Rx', 'Ry', 'Rz']
